/*
* File Name: rectangle.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef RECTANGLE_H
#define RECTANGLE_H
#include <iostream>
#include "square.h"
using namespace std;

class Rectangle : public Square
{
    protected: 
        double side_b;

    public:
        Rectangle(int x, int y, double side_a, double side_b, const char* name);

        double area() const;
        double perimeter() const;

        void set_side_b(double side_b);
        double get_side_b() const;

        void display() const;
};

#endif