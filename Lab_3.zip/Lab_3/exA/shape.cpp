/*
* File Name: shape.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include <cstring>
#include <cstdlib>
#include "shape.h"
using namespace std;

Shape::Shape(const Point& origin, const char* name)
: origin(origin)
{
    if (name) {
        shapeName = new char[strlen(name) + 1]; 
        strcpy(shapeName, name);           
    } else {
        shapeName = 0;
    }
}

Shape::Shape(const Shape& other)
: origin(other.origin)
{
    if (other.shapeName) {
        shapeName = new char[strlen(other.shapeName) + 1];
        strcpy(shapeName, other.shapeName);
    } else {
        shapeName = nullptr;
    }
}

Shape& Shape::operator=(const Shape& other)
{
    if (this != &other) {
        origin = other.origin;  

        delete[] shapeName;

        if (other.shapeName) {
            shapeName = new char[strlen(other.shapeName) + 1];
            strcpy(shapeName, other.shapeName);
        } else {
            shapeName = nullptr;
        }
    }
    return *this;
}

Shape::~Shape()
{
    delete[] shapeName;
}

const Point& Shape::getOrigin() const
{
    return origin;
}

const char* Shape::getName() const
{
    return shapeName;
}

void Shape::display() const
{
    std::cout << "Shape Name: " << shapeName << std::endl;
    std::cout << "X-coordinate: " << origin.getx() << std::endl;
    std::cout << "Y-coordinate: " << origin.gety() << std::endl;

}

double Shape::distance (Shape& other)
{
    return origin.distance(other.origin);
}

double Shape::distance(Shape& the_shape, Shape& other) 
{
    return the_shape.origin.distance(other.origin);
}

void Shape::move(double dx, double dy)
{
    origin.setx(origin.getx() + dx);
    origin.sety(origin.gety() + dy);
}