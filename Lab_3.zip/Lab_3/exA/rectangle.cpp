/*
* File Name: rectangle.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include "rectangle.h"
using namespace std;

Rectangle::Rectangle(int x, int y, double side_a, double side_b, const char* name)
: Shape(Point(x, y), name), Square(x, y, side_a, name), side_b(side_b) {}

double Rectangle::get_side_b() const {
    return side_b;
}

void Rectangle::set_side_b(double side_b) {
    this->side_b = side_b;
}

double Rectangle::area() const {
    return get_side() * side_b;
}

double Rectangle::perimeter() const {
    return (2 * (get_side()+side_b));
}

// Display
void Rectangle::display() const {
    cout << "Rectangle Name: " << getName() << endl;
    cout << "X-coordinate: " << getOrigin().getx() << endl;
    cout << "Y-coordinate: " << getOrigin().gety() << endl;
    cout << "Side a: " << get_side() << endl;
    cout << "Side b: " << get_side_b() << endl;
    cout << "Area: " << area() << endl;
    cout << "Perimeter: " << perimeter() << endl;
}