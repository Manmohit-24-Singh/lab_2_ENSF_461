/*
* File Name: square.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef SQUARE_H
#define SQUARE_H
#include <iostream>
#include "shape.h"
using namespace std;

class Square : virtual public Shape
{
    protected: 
        double side_a;

    public:
        Square(int x, int y, double side, const char* name);

        double area() const;
        double perimeter() const;

        void set_side_a(double side);
        double get_side() const;

        void display() const;
};

#endif