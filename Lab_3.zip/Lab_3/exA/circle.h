/*
* File Name: circle.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef CIRCLE_H
#define CIRCLE_H
#include <iostream>
#include "shape.h"
using namespace std;

class Circle : virtual public Shape
{
    protected: 
        double radius;

    public:
        Circle(int x, int y, double radius, const char* name);

        double area() const;
        double perimeter() const;

        void set_radius(double radius);
        double get_radius() const;

        void display() const;
};

#endif