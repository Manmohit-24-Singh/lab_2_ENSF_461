/*
* File Name: graphicsWorld.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef GRAPHICSWORLD_H
#define GRAPHICSWORLD_H
#include <iostream>
#include "shape.h"
#include "point.h"
#include "square.h"
#include "rectangle.h"
using namespace std;

class GraphicsWorld
{
public:
    void run();
};

#endif