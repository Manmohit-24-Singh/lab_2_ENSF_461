/*
* File Name: shape.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef SHAPE_H
#define SHAPE_H
#include <iostream>
#include "point.h"
using namespace std;

class Shape
{
    protected: 
        Point origin;
        char* shapeName;

    public:
        Shape(const Point& origin, const char* shapeName);
        Shape(const Shape& other);
        Shape& operator=(const Shape& other);
        virtual ~Shape();

        const Point& getOrigin() const;
        const char* getName() const;

        virtual void display() const;
        
        // Add virtual functions for polymorphism
        virtual double area() const { return 0.0; }
        virtual double perimeter() const { return 0.0; }

        double distance (Shape& other);
        static double distance(Shape& the_shape, Shape& other);

        void move (double dx, double dy);
};

#endif