/*
* File Name: square.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include "square.h"
using namespace std;

Square::Square(int x, int y, double side, const char* name)
: Shape(Point(x, y), name), side_a(side) {}

double Square::get_side() const {
    return side_a;
}

void Square::set_side_a(double side) {
    side_a = side;
}

double Square::area() const {
    return side_a * side_a;
}

double Square::perimeter() const {
    return 4 * side_a;
}

// Display
void Square::display() const {
    cout << "Square Name: " << getName() << endl;
    cout << "X-coordinate: " << getOrigin().getx() << endl;
    cout << "Y-coordinate: " << getOrigin().gety() << endl;
    cout << "Side a: " << get_side() << endl;
    cout << "Area: " << area() << endl;
    cout << "Perimeter: " << perimeter() << endl;
}