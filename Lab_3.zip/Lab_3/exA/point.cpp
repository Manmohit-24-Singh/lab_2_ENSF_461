/*
* File Name: point.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include <stdlib.h>
#include "point.h"
using namespace std;

int Point::next_id = 1000;
int Point::object_count = 0;

// Constructor
Point::Point(double x, double y)
: x(x), y(y)
{
    id = next_id++;
    object_count++;
}

//Display
void Point::display() const{
    cout<<"X-coordinate: "<<getx()<<endl;
    cout<<"Y-coordinate: "<<gety()<<endl;
}

//Counter
int Point::counter(){
    return object_count;
}

//Distance
double Point::distance(const Point& p) const {
    double dx = p.x - x;
    double dy = p.y - y;
    return std::sqrt(dx * dx + dy * dy);
}

// Static Distance 
double Point::distance(const Point& p1, const Point& p2) {
    double dx = p2.x - p1.x;
    double dy = p2.y - p1.y;
    return std::sqrt(dx * dx + dy * dy);
}

//Setters
void Point::setx(double x){
    this->x = x;
}

void Point::sety(double y){
    this->y = y;
}

//Getters
double Point::getx() const{
    return x;
}

double Point::gety() const{
    return y;
}

int Point::getid() const{
    return id;
}