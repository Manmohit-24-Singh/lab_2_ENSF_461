/*
* File Name: curvecut.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#ifndef CURVECUT_H
#define CURVECUT_H
#include <iostream>
#include "rectangle.h"
#include "circle.h"
using namespace std;

class CurveCut : public Rectangle, public Circle
{
    public:
        CurveCut(int x, int y, double side_a, double side_b, double radius, const char* name);

        // Copy constructor
        CurveCut(const CurveCut& other);

        // Assignment operator
        CurveCut& operator=(const CurveCut& other);

        double area() const;
        double perimeter() const;

        void display() const;
        
        double distance(Shape& other);
        
        void move(double dx, double dy);
        
        const char* getName() const;
        
        const Point& getOrigin() const;
};

#endif