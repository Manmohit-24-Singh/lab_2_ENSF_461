/*
* File Name: circle.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include <cmath>
#include "circle.h"
using namespace std;

Circle::Circle(int x, int y, double radius, const char* name)
: Shape(Point(x, y), name), radius(radius) {}

double Circle::get_radius() const {
    return radius;
}

void Circle::set_radius(double radius) {
    this->radius = radius;
}

double Circle::area() const {
    return M_PI * radius * radius;
}

double Circle::perimeter() const {
    return 2 * M_PI * radius;
}

// Display
void Circle::display() const {
    cout << "Circle Name: " << getName() << endl;
    cout << "X-coordinate: " << getOrigin().getx() << endl;
    cout << "Y-coordinate: " << getOrigin().gety() << endl;
    cout << "Radius: " << get_radius() << endl;
    cout << "Area: " << area() << endl;
    cout << "Perimeter: " << perimeter() << endl;
}