/*
* File Name: point.h
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/



#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;

class Point
{
    private: 
        double x;
        double y;
        int id;                    
        static int next_id;         
        static int object_count;

    public:
        Point(double x, double y);

        void display() const;

        static int counter();

        double distance(const Point& p) const;

        static double distance(const Point& p1, const Point& p2);

        void setx(double x);
        void sety(double y);

        double getx() const;
        double gety() const;
        int getid() const;
};

#endif