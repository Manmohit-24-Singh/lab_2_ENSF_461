/*
* File Name: curvecut.cpp
* Assignment: Lab 3 Exercise A
* Completed by: Manmohit Singh
* Submission Date: Sept 26, 2025
*/

#include <iostream>
#include <cmath>
#include <cstdlib>
#include "curvecut.h"
using namespace std;

CurveCut::CurveCut(int x, int y, double side_a, double side_b, double radius, const char* name)
: Shape(Point(x, y), name), Rectangle(x, y, side_a, side_b, name), Circle(x, y, radius, name)
{
    // Check if radius is valid
    double smaller_side = (side_a < side_b) ? side_a : side_b;
    if (radius > smaller_side) {
        cout << "Radius error." << endl;
        exit(1);
    }
}

// Copy constructor for virtual inheritance
CurveCut::CurveCut(const CurveCut& other)
: Shape(other.getOrigin(), other.getName()), 
  Rectangle(other.getOrigin().getx(), other.getOrigin().gety(), other.get_side(), other.get_side_b(), other.getName()),
  Circle(other.getOrigin().getx(), other.getOrigin().gety(), other.get_radius(), other.getName())
{
}

// Assignment operator  
CurveCut& CurveCut::operator=(const CurveCut& other)
{
    if (this != &other) {
        Rectangle::operator=(other);
        Circle::operator=(other);
    }
    return *this;
}


double CurveCut::area() const {
    // Area = Rectangle area - Quarter circle area
    double rectangle_area = Rectangle::area();
    double quarter_circle_area = (M_PI * get_radius() * get_radius()) / 4.0;
    return rectangle_area - quarter_circle_area;
}

double CurveCut::perimeter() const {
    // Perimeter = Rectangle perimeter - 2*radius + quarter circle arc
    double rectangle_perimeter = Rectangle::perimeter();
    double quarter_circle_arc = (2.0 * M_PI * get_radius()) / 4.0;
    return rectangle_perimeter - (2.0 * get_radius()) + quarter_circle_arc;
}

void CurveCut::display() const {
    cout << "CurveCut Name: " << Rectangle::getName() << endl;
    cout << "X-coordinate: " << Rectangle::getOrigin().getx() << endl;
    cout << "Y-coordinate: " << Rectangle::getOrigin().gety() << endl;
    cout << "Width: " << get_side() << endl;
    cout << "Length: " << get_side_b() << endl;
    cout << "Radius of the cut: " << get_radius() << endl;
}

// Resolve ambiguity by using Rectangle's distance function
double CurveCut::distance(Shape& other) {
    return Rectangle::distance(other);
}

// Resolve ambiguity by using Rectangle's move function
void CurveCut::move(double dx, double dy) {
    Rectangle::move(dx, dy);
    Circle::move(dx, dy);
}

// Resolve ambiguity by using Rectangle's getName function
const char* CurveCut::getName() const {
    return Rectangle::getName();
}

// Resolve ambiguity by using Rectangle's getOrigin function
const Point& CurveCut::getOrigin() const {
    return Rectangle::getOrigin();
}