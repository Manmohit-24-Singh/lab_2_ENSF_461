#include "util.h"


int* read_next_line(FILE* fin) {
    // TODO: This function reads the next line from the input file
    // The line is a comma-separated list of integers
    // Return the list of integers as an array where the first element
    // is the number of integers in the rest of the array
    // Return NULL if there are no more lines to read

    char ln[1024]; // Buffer for holding a line
    
    if (fgets(ln, sizeof(ln), fin) == NULL) {
        return NULL; // No lines left to read
    }

    int capacity = 10; // Initial guess for number of elements + 1 for count
    int* rslt = (int*)malloc(capacity * sizeof(int));
    if (rslt == NULL) {
        printf("Memory Error");
        exit(1);
    }
    
    int count = 0;
    int current_number = 0;
    int negative = 0;
    int parsing_number = 0;

    // Iterate through the line string
    for (int i = 0; ln[i] != '\0'; i++) {
        char c = ln[i];

        if (c >= '0' && c <= '9') {
            // It's a digit: accumulate the number value
            current_number = current_number * 10 + (c - '0');
            parsing_number = 1;
        } else if (c == ',' || c == '\n') {
            if (parsing_number) {
                // Number finished (by comma or newline)
                
                // 1. Store the number
                count++;
                if (count + 1 > capacity) {
                    capacity *= 2;
                    int* new_rslt = (int*)realloc(rslt, capacity * sizeof(int));
                    if (new_rslt == NULL) {
                        free(rslt);
                        printf("Memory Error on realloc");
                        exit(1);
                    }
                    rslt = new_rslt;
                }
                rslt[count] = current_number;

                // 2. Reset for next number
                current_number = 0;
                negative = 0;
                parsing_number = 0;
            }
            if (c == '\n') break; // Stop after processing the newline (or if we hit a null terminator)
        }
        // Ignore any other character (like a space) or a trailing comma not followed by a number
    }
    
    if (count == 0) {
        free(rslt);
        return NULL; // Line was empty or contained no valid numbers
    }

    rslt[0] = count; // Store the number of integers at the first position
    
    // Resize down to save memory
    int* final_rslt = (int*)realloc(rslt, (count + 1) * sizeof(int));
    if (final_rslt == NULL) {
        return rslt; // Realloc failed, return the existing block
    }

    return final_rslt;
}



float compute_average(int* line) {
    // TODO: Compute the average of the integers in the vector
    // Recall that the first element of the vector is the number of integers

    int count = line[0];
    if (count == 0) {
        return 0.0f;
    }

    long long sum = 0;
    for (int i = 1; i <= count; i++) {
        sum += line[i];
    }

    return (float)sum / count;

}


float compute_stdev(int* line) {
    // TODO: Compute the standard deviation of the integers in the vector
    // Recall that the first element of the vector is the number of integers

    int count = line[0];
    if (count <= 1) {
        return 0.0f;
    }

    float avg = compute_average(line);
    float sum_sq_diff = 0.0f;

    for (int i = 1; i <= count; i++) {
        float diff = (float)line[i] - avg;
        sum_sq_diff += diff * diff;
    }

    float variance = sum_sq_diff / (count - 1); 

    return sqrtf(variance);

}